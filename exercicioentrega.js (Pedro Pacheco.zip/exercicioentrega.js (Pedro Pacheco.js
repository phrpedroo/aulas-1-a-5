var http = require('http');
var teste = require('./exercicionode.js');
const { info } = require('console');

http.createServer(function (req, res){
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write('<html>')
    res.write('<body>')
    res.write('<h1>' + teste.minhaInformacao + '</h1>' );
    res.write('<p>' + teste.dbuserxpto + '</p>');
    res.write('<p>' +  teste.dbpass + '</p>');
    res.write('</body>');
    res.write('</html>');
    res.end();
}).listen(8080);
